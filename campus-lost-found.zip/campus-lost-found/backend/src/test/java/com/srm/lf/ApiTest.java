package com.srm.lf;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = "spring.datasource.url=jdbc:h2:mem:t2") @AutoConfigureMockMvc
class ApiTest {
  @Autowired MockMvc mvc;
  @Test void listReturnsSeedData() throws Exception { mvc.perform(get("/api/items")).andExpect(status().isOk()).andExpect(jsonPath("$[0].title").exists()); }
  @Test void searchFiltersByKeyword() throws Exception { mvc.perform(get("/api/items?q=jbl")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1)); }
  @Test void invalidItemReturns400() throws Exception { mvc.perform(post("/api/items").contentType("application/json").content("{\"type\":\"X\"}")).andExpect(status().isBadRequest()); }
  @Test void claimsListNeedsAdminKey() throws Exception { mvc.perform(get("/api/claims")).andExpect(status().isUnauthorized()); }
}
