package com.srm.lf;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(properties = "spring.datasource.url=jdbc:h2:mem:t1") @Transactional
class LfServiceTest {
  @Autowired LfService svc;
  Item item() {
    Item i = new Item(); i.type = "FOUND"; i.title = "Blue bottle"; i.description = "Blue steel bottle with sticker"; i.category = "Other";
    i.location = "Canteen"; i.date = LocalDate.now(); i.contactName = "Tester"; i.contactEmail = "t@x.com"; return svc.create(i);
  }
  Claim claim(String mail) { Claim c = new Claim(); c.claimantName = "Asha"; c.claimantEmail = mail; c.proof = "Has my initials scratched underneath"; return c; }

  @Test void duplicateClaimIsRejected() {
    Item i = item(); svc.claim(i.id, claim("a@x.com"));
    assertThrows(IllegalStateException.class, () -> svc.claim(i.id, claim("A@x.com")));
  }
  @Test void approvalReturnsItemAndRejectsOtherClaims() {
    Item i = item(); Claim a = svc.claim(i.id, claim("a@x.com")); Claim b = svc.claim(i.id, claim("b@x.com"));
    assertEquals("UNDER_REVIEW", svc.get(i.id).status);
    svc.decide(a.id, true);
    assertEquals("RETURNED", svc.get(i.id).status); assertEquals("REJECTED", b.status);
    assertThrows(IllegalStateException.class, () -> svc.claim(i.id, claim("c@x.com")));
  }
  @Test void rejectingOnlyClaimReopensItem() {
    Item i = item(); Claim a = svc.claim(i.id, claim("a@x.com")); svc.decide(a.id, false);
    assertEquals("OPEN", svc.get(i.id).status);
  }
}
