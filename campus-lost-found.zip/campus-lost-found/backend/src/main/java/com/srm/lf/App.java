package com.srm.lf;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import java.time.LocalDate;

@SpringBootApplication
public class App {
  public static void main(String[] a) { SpringApplication.run(App.class, a); }

  /** Synthetic demo data (only when the table is empty). */
  @Bean CommandLineRunner seed(ItemRepo r) {
    return x -> {
      if (r.count() > 0) return;
      mk(r, "FOUND", "Black JBL earbuds case", "Black charging case with JBL logo and a scratch on the lid", "Electronics", "Library, 2nd floor", 1);
      mk(r, "LOST", "Blue steel water bottle", "Blue steel bottle with a football sticker on the side", "Other", "Canteen", 2);
      mk(r, "FOUND", "Student ID card", "SRM ID card found near the main gate, name partly faded", "ID & Cards", "Main gate", 3);
      mk(r, "LOST", "Casio scientific calculator", "Casio fx-991EX with initials KR written on the back", "Electronics", "Block A, Room 204", 4);
      mk(r, "FOUND", "Blue bottle with sticker", "Steel water bottle, blue, football sticker, left on a bench", "Other", "Canteen bench", 1);
      mk(r, "LOST", "House keys with red keychain", "Three keys on a red ring with a small bell", "Keys", "Sports ground", 5);
    };
  }
  private void mk(ItemRepo r, String type, String title, String desc, String cat, String loc, int daysAgo) {
    Item i = new Item(); i.type = type; i.title = title; i.description = desc; i.category = cat; i.location = loc;
    i.date = LocalDate.now().minusDays(daysAgo); i.contactName = "Demo User"; i.contactEmail = "demo@example.com"; r.save(i);
  }
}
