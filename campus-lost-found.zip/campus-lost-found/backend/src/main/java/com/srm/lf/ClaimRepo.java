package com.srm.lf;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ClaimRepo extends JpaRepository<Claim, Long> {
  List<Claim> findByItemId(Long itemId);
  boolean existsByItemIdAndClaimantEmailIgnoreCase(Long itemId, String email);
}
