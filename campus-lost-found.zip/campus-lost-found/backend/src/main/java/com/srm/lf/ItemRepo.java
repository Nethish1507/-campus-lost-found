package com.srm.lf;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ItemRepo extends JpaRepository<Item, Long> {
  @Query("select i from Item i where (:q is null or lower(i.title) like lower(concat('%',:q,'%')) or lower(i.description) like lower(concat('%',:q,'%')) or lower(i.location) like lower(concat('%',:q,'%'))) "
       + "and (:type is null or i.type=:type) and (:cat is null or i.category=:cat) and (:status is null or i.status=:status) order by i.date desc, i.id desc")
  List<Item> search(@Param("q") String q, @Param("type") String type, @Param("cat") String cat, @Param("status") String status);
}
