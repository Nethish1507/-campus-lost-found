package com.srm.lf;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.NoSuchElementException;

/** Business layer: all lost-and-found rules live here. */
@Service @Transactional
public class LfService {
  private final ItemRepo items; private final ClaimRepo claims;
  public LfService(ItemRepo i, ClaimRepo c) { items = i; claims = c; }

  public Item get(Long id) { return items.findById(id).orElseThrow(() -> new NoSuchElementException("Item " + id + " not found")); }
  public Item create(Item i) { i.id = null; i.status = "OPEN"; return items.save(i); }
  public Item update(Long id, Item n) {
    Item o = get(id);
    o.type = n.type; o.title = n.title; o.description = n.description; o.category = n.category;
    o.location = n.location; o.date = n.date; o.contactName = n.contactName; o.contactEmail = n.contactEmail;
    return o;
  }
  public void delete(Long id) { Item i = get(id); claims.deleteAll(claims.findByItemId(id)); items.delete(i); }

  /** Rule: no claims on returned items; one claim per email per item. */
  public Claim claim(Long itemId, Claim c) {
    Item it = get(itemId);
    if ("RETURNED".equals(it.status)) throw new IllegalStateException("This item has already been returned to its owner");
    if (claims.existsByItemIdAndClaimantEmailIgnoreCase(itemId, c.claimantEmail)) throw new IllegalStateException("You have already submitted a claim for this item");
    c.id = null; c.item = it; c.status = "PENDING"; it.status = "UNDER_REVIEW";
    return claims.save(c);
  }

  /** Rule: approving returns the item and auto-rejects other pending claims; rejecting the last pending claim reopens it. */
  public Claim decide(Long claimId, boolean approve) {
    Claim c = claims.findById(claimId).orElseThrow(() -> new NoSuchElementException("Claim " + claimId + " not found"));
    if (!"PENDING".equals(c.status)) throw new IllegalStateException("Claim is already " + c.status.toLowerCase());
    Item it = c.item;
    if (approve) {
      c.status = "APPROVED"; it.status = "RETURNED";
      claims.findByItemId(it.id).stream().filter(o -> !o.id.equals(c.id) && "PENDING".equals(o.status)).forEach(o -> o.status = "REJECTED");
    } else {
      c.status = "REJECTED";
      if (claims.findByItemId(it.id).stream().noneMatch(o -> "PENDING".equals(o.status))) it.status = "OPEN";
    }
    return c;
  }
}
