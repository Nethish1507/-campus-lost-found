package com.srm.lf;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import java.util.*;

/** Presentation layer: REST controller. Admin endpoints need the X-Admin-Key header. */
@RestController @RequestMapping("/api") @CrossOrigin
public class Api {
  private final LfService svc; private final ItemRepo items; private final JdbcTemplate jdbc;
  @Value("${admin.key}") String adminKey;
  @Value("${match.url}") String matchUrl;
  public Api(LfService s, ItemRepo i, JdbcTemplate j) { svc = s; items = i; jdbc = j; }

  private void admin(String k) { if (!adminKey.equals(k)) throw new SecurityException("Invalid or missing admin key"); }
  private String blank(String s) { return s == null || s.isBlank() ? null : s.trim(); }

  @GetMapping("/items") List<Item> list(@RequestParam(required = false) String q, @RequestParam(required = false) String type,
      @RequestParam(required = false) String category, @RequestParam(required = false) String status) {
    return items.search(blank(q), blank(type), blank(category), blank(status));
  }
  @GetMapping("/items/{id}") Item one(@PathVariable Long id) { return svc.get(id); }
  @PostMapping("/items") ResponseEntity<Item> create(@Valid @RequestBody Item i) { return ResponseEntity.status(201).body(svc.create(i)); }
  @PutMapping("/items/{id}") Item update(@PathVariable Long id, @Valid @RequestBody Item i, @RequestHeader(value = "X-Admin-Key", required = false) String k) { admin(k); return svc.update(id, i); }
  @DeleteMapping("/items/{id}") ResponseEntity<Void> delete(@PathVariable Long id, @RequestHeader(value = "X-Admin-Key", required = false) String k) { admin(k); svc.delete(id); return ResponseEntity.noContent().build(); }

  @PostMapping("/items/{id}/claims") ResponseEntity<Claim> claim(@PathVariable Long id, @Valid @RequestBody Claim c) { return ResponseEntity.status(201).body(svc.claim(id, c)); }

  /** JDBC + SQL JOIN: claims with their item titles. */
  @GetMapping("/claims") List<Map<String, Object>> claims(@RequestHeader(value = "X-Admin-Key", required = false) String k) {
    admin(k);
    return jdbc.query("SELECT c.id, c.status, c.claimant_name, c.claimant_email, c.proof, i.id, i.title FROM claims c JOIN items i ON c.item_id = i.id ORDER BY c.created_at DESC",
      (rs, n) -> Map.of("id", rs.getLong(1), "status", rs.getString(2), "claimantName", rs.getString(3), "claimantEmail", rs.getString(4),
                        "proof", rs.getString(5), "itemId", rs.getLong(6), "itemTitle", rs.getString(7)));
  }
  @PatchMapping("/claims/{id}") Claim decide(@PathVariable Long id, @RequestParam String decision, @RequestHeader(value = "X-Admin-Key", required = false) String k) {
    admin(k); return svc.decide(id, "approve".equals(decision));
  }

  @GetMapping("/stats") Map<String, Object> stats() {
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("total", items.count());
    for (String s : List.of("OPEN", "UNDER_REVIEW", "RETURNED")) m.put(s, jdbc.queryForObject("SELECT COUNT(*) FROM items WHERE status = ?", Long.class, s));
    m.put("pendingClaims", jdbc.queryForObject("SELECT COUNT(*) FROM claims WHERE status = 'PENDING'", Long.class));
    m.put("byCategory", jdbc.query("SELECT category, COUNT(*) FROM items GROUP BY category ORDER BY 2 DESC", (rs, n) -> Map.of("category", rs.getString(1), "count", rs.getLong(2))));
    return m;
  }

  /** Calls the separate match-service (microservice) for similar items of the opposite type. */
  @GetMapping("/items/{id}/matches") List<?> matches(@PathVariable Long id) {
    Item it = svc.get(id);
    List<Item> others = items.search(null, "LOST".equals(it.type) ? "FOUND" : "LOST", null, "OPEN");
    try { return new RestTemplate().postForObject(matchUrl + "/match", Map.of("item", it, "candidates", others), List.class); }
    catch (Exception e) { return List.of(); } // service down -> degrade gracefully
  }
}

@RestControllerAdvice
class Errors {
  private ResponseEntity<Map<String, Object>> r(HttpStatus s, String m) { return ResponseEntity.status(s).body(Map.of("message", m)); }
  @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<Map<String, Object>> invalid(MethodArgumentNotValidException e) {
    Map<String, String> errs = new HashMap<>(); e.getBindingResult().getFieldErrors().forEach(f -> errs.put(f.getField(), f.getDefaultMessage()));
    return ResponseEntity.badRequest().body(Map.of("message", "Please fix the highlighted fields", "errors", errs));
  }
  @ExceptionHandler(NoSuchElementException.class) ResponseEntity<Map<String, Object>> nf(Exception e) { return r(HttpStatus.NOT_FOUND, e.getMessage()); }
  @ExceptionHandler(IllegalStateException.class) ResponseEntity<Map<String, Object>> conflict(Exception e) { return r(HttpStatus.CONFLICT, e.getMessage()); }
  @ExceptionHandler(SecurityException.class) ResponseEntity<Map<String, Object>> auth(Exception e) { return r(HttpStatus.UNAUTHORIZED, e.getMessage()); }
}
