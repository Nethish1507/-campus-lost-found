package com.srm.lf;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

/** Domain entity: a lost or found item posted on the portal. */
@Entity @Table(name = "items")
public class Item {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
  @Pattern(regexp = "LOST|FOUND", message = "Type must be LOST or FOUND") public String type;
  @NotBlank @Size(max = 80) public String title;
  @NotBlank @Size(min = 10, max = 500, message = "Description must be 10-500 characters") public String description;
  @NotBlank public String category;
  @NotBlank public String location;
  @NotNull @PastOrPresent(message = "Date cannot be in the future") public LocalDate date;
  @NotBlank public String contactName;
  @NotBlank @Email @JsonProperty(access = JsonProperty.Access.WRITE_ONLY) public String contactEmail; // never exposed publicly
  public String status = "OPEN"; // OPEN -> UNDER_REVIEW -> RETURNED
}
