package com.srm.lf;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

/** A request by a person to claim an item; many claims belong to one Item. */
@Entity @Table(name = "claims")
public class Claim {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
  @ManyToOne(optional = false) public Item item;
  @NotBlank public String claimantName;
  @NotBlank @Email public String claimantEmail;
  @NotBlank @Size(min = 10, message = "Describe proof of ownership (min 10 characters)") public String proof;
  public String status = "PENDING"; // PENDING, APPROVED, REJECTED
  public LocalDateTime createdAt = LocalDateTime.now();
}
