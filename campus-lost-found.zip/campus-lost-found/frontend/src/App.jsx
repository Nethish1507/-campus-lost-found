import { useEffect, useState } from "react";
import { Routes, Route, Link, NavLink, useParams, useNavigate, useSearchParams } from "react-router-dom";

const API = import.meta.env.VITE_API || "/api";
const CATS = ["Electronics", "ID & Cards", "Books & Stationery", "Clothing", "Bags", "Keys", "Wallets", "Other"];
const today = () => new Date().toISOString().slice(0, 10);

async function api(path, opts = {}, key) {
  const r = await fetch(API + path, { ...opts, headers: { "Content-Type": "application/json", ...(key ? { "X-Admin-Key": key } : {}) } });
  const d = r.status === 204 ? null : await r.json().catch(() => null);
  if (!r.ok) throw d || { message: "Server unreachable or request failed" };
  return d;
}

// client-side validation: required, email format, min length
const check = (f, min = {}) => Object.fromEntries(Object.entries(f).flatMap(([k, v]) => {
  v = String(v).trim();
  if (!v) return [[k, "This field is required"]];
  if (/email/i.test(k) && !/^\S+@\S+\.\S+$/.test(v)) return [[k, "Enter a valid email"]];
  if (min[k] && v.length < min[k]) return [[k, `At least ${min[k]} characters`]];
  return [];
}));

/* ---------- reusable components ---------- */
const Badge = ({ s }) => <span className={`badge ${s}`}>{s.replace("_", " ")}</span>;
const Msg = ({ m }) => m && <div className={m.ok ? "msg ok" : "msg bad"} role="alert">{m.ok || m.bad}</div>;
function Field({ label, error, as: T = "input", children, ...p }) {
  return <label>{label}<T {...p}>{children}</T>{error && <small className="err">{error}</small>}</label>;
}
function ItemCard({ it }) {
  return (
    <Link to={`/item/${it.id}`} className="card">
      <div className="row"><span className={`tag ${it.type}`}>{it.type}</span><Badge s={it.status} /></div>
      <h3>{it.title}</h3>
      <p className="muted">{it.description.slice(0, 90)}{it.description.length > 90 ? "…" : ""}</p>
      <small>📍 {it.location} · 🗓 {it.date}</small>
    </Link>
  );
}

/* ---------- views ---------- */
function Home() {
  const [f, setF] = useState({ q: "", type: "", category: "", status: "" });
  const [items, setItems] = useState([]), [stats, setStats] = useState(null), [loading, setLoading] = useState(true);
  useEffect(() => { api("/stats").then(setStats).catch(() => {}); }, []);
  useEffect(() => {
    const t = setTimeout(() => {
      setLoading(true);
      api("/items?" + new URLSearchParams(f)).then(setItems).catch(() => setItems([])).finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(t);
  }, [f]);
  const set = k => e => setF({ ...f, [k]: e.target.value });
  return (
    <>
      <section className="hero">
        <h1>Lost something on campus? Found something?</h1>
        <p>Post it, search it, claim it — all in one place.</p>
        <div className="row center"><Link className="btn" to="/post?type=LOST">I lost an item</Link><Link className="btn alt" to="/post?type=FOUND">I found an item</Link></div>
        {stats && <div className="stats"><b>{stats.total}</b> posted · <b>{stats.OPEN}</b> open · <b>{stats.RETURNED}</b> returned to owners</div>}
      </section>
      <section className="filters">
        <input placeholder="Search title, description, location…" value={f.q} onChange={set("q")} aria-label="Search" />
        <select value={f.type} onChange={set("type")}><option value="">Lost &amp; Found</option><option value="LOST">Lost</option><option value="FOUND">Found</option></select>
        <select value={f.category} onChange={set("category")}><option value="">All categories</option>{CATS.map(c => <option key={c}>{c}</option>)}</select>
        <select value={f.status} onChange={set("status")}><option value="">Any status</option><option value="OPEN">Open</option><option value="UNDER_REVIEW">Under review</option><option value="RETURNED">Returned</option></select>
      </section>
      {loading ? <p className="muted">Loading…</p> : items.length ? <div className="grid">{items.map(i => <ItemCard key={i.id} it={i} />)}</div> : <p className="muted">No items match your search.</p>}
    </>
  );
}

function Detail() {
  const { id } = useParams();
  const blank = { claimantName: "", claimantEmail: "", proof: "" };
  const [it, setIt] = useState(null), [matches, setM] = useState([]), [msg, setMsg] = useState(null), [f, setF] = useState(blank), [err, setErr] = useState({});
  const load = () => api(`/items/${id}`).then(setIt).catch(e => setMsg({ bad: e.message }));
  useEffect(() => { load(); api(`/items/${id}/matches`).then(setM).catch(() => setM([])); }, [id]);
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const submit = async e => {
    e.preventDefault();
    const v = check(f, { proof: 10 }); setErr(v);
    if (Object.keys(v).length) return;
    try {
      await api(`/items/${id}/claims`, { method: "POST", body: JSON.stringify(f) });
      setMsg({ ok: "Claim submitted! Campus staff will verify it and contact you by email." }); setF(blank); load();
    } catch (x) { setErr(x.errors || {}); setMsg({ bad: x.message }); }
  };
  if (!it) return <Msg m={msg} />;
  return (
    <div className="detail">
      <Link to="/">← Back to listings</Link>
      <div className="panel">
        <div className="row"><span className={`tag ${it.type}`}>{it.type}</span><Badge s={it.status} /></div>
        <h2>{it.title}</h2><p>{it.description}</p>
        <table><tbody>
          <tr><th>Category</th><td>{it.category}</td></tr><tr><th>Location</th><td>{it.location}</td></tr>
          <tr><th>Date</th><td>{it.date}</td></tr><tr><th>Posted by</th><td>{it.contactName}</td></tr>
        </tbody></table>
      </div>
      <Msg m={msg} />
      {it.status !== "RETURNED" ? (
        <form className="panel" onSubmit={submit} noValidate>
          <h3>{it.type === "FOUND" ? "This is mine — claim it" : "I found this item"}</h3>
          <Field label="Your name" value={f.claimantName} onChange={set("claimantName")} error={err.claimantName} />
          <Field label="Your email" type="email" value={f.claimantEmail} onChange={set("claimantEmail")} error={err.claimantEmail} />
          <Field as="textarea" rows="3" label="Proof / identifying details (only the real owner would know)" value={f.proof} onChange={set("proof")} error={err.proof} />
          <button className="btn">Submit claim</button>
        </form>
      ) : <p className="msg ok">This item has been returned to its owner.</p>}
      {matches.length > 0 && <><h3>Possible matches</h3><div className="grid">{matches.map(m => <div key={m.id}><ItemCard it={m} /><small>Match score {Math.round(m.score * 100)}%</small></div>)}</div></>}
    </div>
  );
}

function Post() {
  const [sp] = useSearchParams(), nav = useNavigate();
  const [f, setF] = useState({ type: sp.get("type") === "FOUND" ? "FOUND" : "LOST", title: "", description: "", category: CATS[0], location: "", date: today(), contactName: "", contactEmail: "" });
  const [err, setErr] = useState({}), [msg, setMsg] = useState(null);
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const submit = async e => {
    e.preventDefault();
    const v = check(f, { description: 10 }); if (f.date > today()) v.date = "Date cannot be in the future";
    setErr(v); if (Object.keys(v).length) return;
    try { const r = await api("/items", { method: "POST", body: JSON.stringify(f) }); nav(`/item/${r.id}`); }
    catch (x) { setErr(x.errors || {}); setMsg({ bad: x.message }); }
  };
  return (
    <form className="panel narrow" onSubmit={submit} noValidate>
      <h2>Report an item</h2><Msg m={msg} />
      <Field as="select" label="I…" value={f.type} onChange={set("type")}><option value="LOST">lost an item</option><option value="FOUND">found an item</option></Field>
      <Field label="Item title" value={f.title} onChange={set("title")} error={err.title} maxLength={80} />
      <Field as="textarea" rows="3" label="Description (colour, brand, marks)" value={f.description} onChange={set("description")} error={err.description} />
      <div className="two">
        <Field as="select" label="Category" value={f.category} onChange={set("category")}>{CATS.map(c => <option key={c}>{c}</option>)}</Field>
        <Field type="date" label="Date" max={today()} value={f.date} onChange={set("date")} error={err.date} />
      </div>
      <Field label="Where (building / place)" value={f.location} onChange={set("location")} error={err.location} />
      <div className="two">
        <Field label="Your name" value={f.contactName} onChange={set("contactName")} error={err.contactName} />
        <Field type="email" label="Your email (kept private)" value={f.contactEmail} onChange={set("contactEmail")} error={err.contactEmail} />
      </div>
      <button className="btn">Post item</button>
    </form>
  );
}

function Admin() {
  const [key, setKey] = useState(sessionStorage.getItem("k") || ""), [ok, setOk] = useState(false), [msg, setMsg] = useState(null);
  const [claims, setC] = useState([]), [stats, setS] = useState(null), [items, setI] = useState([]);
  const load = async k => {
    try {
      const [c, s, i] = await Promise.all([api("/claims", {}, k), api("/stats"), api("/items")]);
      setC(c); setS(s); setI(i); setOk(true); sessionStorage.setItem("k", k);
    } catch (e) { setOk(false); setMsg({ bad: e.message }); }
  };
  useEffect(() => { if (key) load(key); }, []);
  const act = async (path, method) => { try { await api(path, { method }, key); setMsg({ ok: "Done" }); load(key); } catch (e) { setMsg({ bad: e.message }); } };
  if (!ok) return (
    <form className="panel narrow" onSubmit={e => { e.preventDefault(); load(key); }}>
      <h2>Staff login</h2><Msg m={msg} />
      <Field type="password" label="Admin key" value={key} onChange={e => setKey(e.target.value)} />
      <button className="btn">Enter</button>
    </form>
  );
  const max = Math.max(1, ...stats.byCategory.map(c => c.count));
  return (
    <div>
      <h2>Staff dashboard</h2><Msg m={msg} />
      <div className="stats big"><span><b>{stats.total}</b>Items</span><span><b>{stats.OPEN}</b>Open</span><span><b>{stats.pendingClaims}</b>Pending claims</span><span><b>{stats.RETURNED}</b>Returned</span></div>
      <div className="panel"><h3>Items by category</h3>{stats.byCategory.map(c => <div className="bar" key={c.category}><span>{c.category}</span><i style={{ width: `${(c.count / max) * 100}%` }} />{c.count}</div>)}</div>
      <h3>Claims verification queue</h3>
      <div className="scroll"><table><thead><tr><th>Item</th><th>Claimant</th><th>Proof</th><th>Status</th><th></th></tr></thead><tbody>
        {claims.map(c => <tr key={c.id}><td><Link to={`/item/${c.itemId}`}>{c.itemTitle}</Link></td><td>{c.claimantName}<br /><small>{c.claimantEmail}</small></td><td>{c.proof}</td><td><Badge s={c.status} /></td>
          <td>{c.status === "PENDING" && <><button className="btn sm" onClick={() => act(`/claims/${c.id}?decision=approve`, "PATCH")}>Approve</button> <button className="btn sm alt" onClick={() => act(`/claims/${c.id}?decision=reject`, "PATCH")}>Reject</button></>}</td></tr>)}
      </tbody></table></div>
      <h3>Manage listings</h3>
      <div className="scroll"><table><tbody>{items.map(i => <tr key={i.id}><td><Link to={`/item/${i.id}`}>{i.title}</Link></td><td>{i.type}</td><td><Badge s={i.status} /></td>
        <td><button className="btn sm alt" onClick={() => window.confirm("Delete this listing and its claims?") && act(`/items/${i.id}`, "DELETE")}>Delete</button></td></tr>)}</tbody></table></div>
    </div>
  );
}

export default function App() {
  return (
    <>
      <header><Link to="/" className="logo">🎒 Campus Lost &amp; Found</Link>
        <nav><NavLink to="/" end>Browse</NavLink><NavLink to="/post">Report item</NavLink><NavLink to="/admin">Staff</NavLink></nav></header>
      <main><Routes><Route path="/" element={<Home />} /><Route path="/item/:id" element={<Detail />} /><Route path="/post" element={<Post />} /><Route path="/admin" element={<Admin />} /><Route path="*" element={<p>Page not found.</p>} /></Routes></main>
      <footer>SRM Institute of Science and Technology, Tiruchirappalli · 21CSE354T Task 4 · Demo data only</footer>
    </>
  );
}
