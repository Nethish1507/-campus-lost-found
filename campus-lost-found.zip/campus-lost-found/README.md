# Campus Lost & Found Portal (21CSE354T · Task 4 · Project #7)
Post lost/found items, search & filter, submit ownership claims, and let staff verify and track collection.

## Architecture (3 tiers + microservice)
`React (Vite) :5173` → `Spring Boot API :8080` (Controller `Api` → Service `LfService` → Domain/JPA `Item`,`Claim`) → `H2 file DB` (or MySQL)
`Spring Boot` → HTTP → `match-service :8081` (Python microservice that ranks similar lost/found items)

## Prerequisites
Java 17+, Maven 3.9+, Node 18+, Python 3.9+ (MySQL 8 optional).

## Run locally (3 terminals)
```bash
cd match-service && python match.py                 # :8081
cd backend && mvn spring-boot:run                    # :8080  (demo data auto-seeded)
cd frontend && npm install && npm run dev            # :5173  -> open http://localhost:5173
```
Staff page: `/admin` — default demo key `demo-admin` (override with `ADMIN_KEY`).

## Environment variables (nothing is committed)
`ADMIN_KEY`, `DB_URL`, `DB_USER`, `DB_PASS`, `MATCH_URL`; frontend `VITE_API` (API base for production builds).
MySQL: `create database lostfound;` then `DB_URL=jdbc:mysql://localhost:3306/lostfound DB_USER=root DB_PASS=*** mvn spring-boot:run` (tables auto-created by JPA).

## Build / deploy
`mvn clean package` → `java -jar target/lostfound-1.0.0.jar` · `npm run build` → serve `frontend/dist` (Netlify/Vercel/Nginx) with `VITE_API=https://<api-host>/api`.

## API
| Method | Endpoint | Notes |
|---|---|---|
| GET | `/api/items?q=&type=&category=&status=` | search/filter |
| GET/POST | `/api/items`, `/api/items/{id}` | create returns 201; 400 with field errors |
| PUT/DELETE | `/api/items/{id}` | admin (`X-Admin-Key`) |
| POST | `/api/items/{id}/claims` | 409 on duplicate claim / returned item |
| GET | `/api/claims` | admin; SQL JOIN via JDBC |
| PATCH | `/api/claims/{id}?decision=approve\|reject` | admin |
| GET | `/api/stats` | counts + by-category (JDBC GROUP BY) |
| GET | `/api/items/{id}/matches` | calls match-service |
| POST | `:8081/match` | `{item, candidates[]}` → ranked candidates with `score` |

## Tests
`cd backend && mvn test` — business rules (duplicate claim, approval/rejection flow) and MockMvc API tests (list, search, validation 400, admin 401).

## Course outcome mapping
CO-1/2: `frontend/src` (routing, forms, hooks, responsive CSS) · CO-3: JDBC queries in `Api.java` + JPA schema · CO-4: layered Spring Boot + tests · CO-5: JPA repositories + `match-service`.
Privacy: contact emails are write-only in the API; demo data is synthetic.
