"""Match microservice (no dependencies). POST /match {item, candidates[]} -> candidates ranked by text similarity.
Run: python match.py   (listens on :8081)"""
import json, re
from http.server import BaseHTTPRequestHandler, HTTPServer

tokens = lambda i: set(re.findall(r"[a-z0-9]+", f"{i['title']} {i['description']} {i['location']}".lower()))

class H(BaseHTTPRequestHandler):
    def do_POST(s):
        if s.path != "/match":
            s.send_response(404); s.end_headers(); return
        d = json.loads(s.rfile.read(int(s.headers["Content-Length"])))
        a, out = tokens(d["item"]), []
        for c in d["candidates"]:
            b = tokens(c)
            score = len(a & b) / max(1, len(a | b)) + (0.2 if c["category"] == d["item"]["category"] else 0)
            if score > 0.25: out.append({**c, "score": round(score, 2)})
        body = json.dumps(sorted(out, key=lambda x: -x["score"])[:5]).encode()
        s.send_response(200); s.send_header("Content-Type", "application/json"); s.send_header("Content-Length", str(len(body))); s.end_headers(); s.wfile.write(body)

HTTPServer(("", 8081), H).serve_forever()
